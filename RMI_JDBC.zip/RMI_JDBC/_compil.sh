cd src
javac Serveur.java
javac Client.java
javac Worker.java
cd ..